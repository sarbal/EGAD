
save(ortho_yeast, ortho_mouse, ortho_zf, ortho_eleg, ortho_dros, file="../data2/ortho.rda")
