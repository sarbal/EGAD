get_phenocarta <- function(species="human", type="all") {

    URL = "http://www.chibi.ubc.ca/Gemma/phenocarta/LatestEvidenceExport/AllPhenocartaAnnotations.tsv"
    data <- read.table(URL,  fill=T, sep="\t", quote="", header=T)

    # Convert to data frame
    data <- as.data.frame(data)

    return(data)
}


save_pheno_net <- function(data, species="human", type="all", fileout="pheno.Rdata") {

    # Fitler file
    filt <- data$Taxon == species & data$Is.Negative == "No"
  
    genes <- unique (data$Gene.NCBI[filt] )
    diseases  <- unique (data$Phenotype.Names[filt] )

    pheno.mat.human <- make_network_from_data ( cbind(data$Gene.NCBI[filt], data$Phenotype.Names[filt]), genes, diseases )
    save(pheno.mat.human, pheno, file=fileout)
    return(pheno.mat.human)
}


make_network_from_data<- function(data, listA, listB){
  nr = length(listA)
  nc = length(listB)
  
  net = matrix(0, ncol=nc, nrow=nr)
  
  m = match( (data[,1]), listA  )
  p1 = !is.na(m)
  m1 = m[p1]
  
  m = match( (data[p1,2]), listB )
  p2 = !is.na(m)
  m2 = m[p2]
  
  net[cbind(m1,m2)] = 1
  
  colnames(net) = listB
  rownames(net) = listA
  return(net)
}

