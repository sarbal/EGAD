get_biogrid <- function(species="9606", version="3.4.131", interactions="physical") {

    # Columns of entrez gene IDs
    col.filt <- c(2, 3)

    URL = "http://thebiogrid.org/downloads/archives/Release%20Archive/"
    filedir= paste("BIOGRID-", version, sep="")
    filename = paste("BIOGRID-ALL-", version, ".tab2.zip", sep="")
    fileURL = paste(URL, filedir, filename, sep="/")
    tempfilein = paste("BIOGRID-ALL-", version, ".tab2.txt", sep="")
    temp = tempfile()

    download.file(fileURL, temp, mode="wb")
    unzip(temp, tempfilein)
    biogrid <- read.table(tempfilein,  fill=T, sep="\t", quote="")
    unlink(temp)

    # Convert data frame
    biogrid <- as.data.frame(biogrid)

    # Get taxon IDs
    ids <- unique(biogrid[, 16])

    # Taxon ID to select
    i <- which(ids == species)

    # Filter for taxon IDs i
    pairs <- biogrid[, 16] == ids[i] & biogrid[, 17] == ids[i] & !is.na(biogrid[, 16]) & !is.na(biogrid[, 17])

    # Only pick interactions (physical or genetic)
    p <- biogrid[pairs, 13] == interactions
    biogrid.all <- cbind(biogrid[pairs, ][p, ])

    # Filter out pairs with same IDs
    filt <- which(as.numeric(biogrid.all[, 2]) != as.numeric(biogrid.all[, 3]))
    biogrid.all <- biogrid.all[filt, ]
    
    return(biogrid.all)
}


save_biogrid_net <- function(filein, fileout) {
    
    # Columns of entrez gene IDs
    col.filt <- c(2, 3)
    # Taxon ID to select
    i <- 1
    
    # Read in biogrid file
    biogrid <- read.table(filein, fill = T, sep = "\t", quote = "")
    # Convert data frame
    biogrid <- as.data.frame(biogrid)

    # Get taxon IDs
    ids <- unique(biogrid[, 16])
    
    # Filter for taxon IDs i
    pairs <- biogrid[, 16] == ids[i] & biogrid[, 17] == ids[i] & !is.na(biogrid[, 16]) & !is.na(biogrid[, 17])

    # Only pick physical interactions
    p <- biogrid[pairs, 13] == "physical"
    biogrid.all <- cbind(biogrid[pairs, ][p, ])
    
    # Filter out pairs with same IDs
    filt <- which(as.numeric(biogrid.all[, 2]) != as.numeric(biogrid.all[, 3]))
    biogrid.all <- biogrid.all[filt, ]
    
    # Collect all gene IDs
    genes <- unique(c(as.character(biogrid.all[, 2]), as.character(biogrid.all[, 3])))

    # Construct binary network
    network <- make_network_from_data(biogrid.all[, col.filt], genes, genes)
    net <- network + t(network)
    net[net == 2] <- 1
    diag(net) <- 1
    
    # Save network and filtered data
    save(net, genes, filt, biogrid.all, col.filt, file = fileout)
} 


make_network_from_data<- function(data, listA, listB){
  nr = length(listA)
  nc = length(listB)
  
  net = matrix(0, ncol=nc, nrow=nr)

  m = match( (data[,1]), listA  )
  p1 = !is.na(m)
  m1 = m[p1]
  
  m = match( (data[p1,2]), listB )
  p2 = !is.na(m)
  m2 = m[p2]
  
  net[cbind(m1,m2)] = 1
  
  colnames(net) = listB
  rownames(net) = listA
  return(net)
}

