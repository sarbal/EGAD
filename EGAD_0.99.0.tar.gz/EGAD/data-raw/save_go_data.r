
get_GOA <- function(species="human", type="all") {

    ftp_releases = "ftp://ftp.ebi.ac.uk/pub/databases/GO/goa/current_release_numbers.txt"
    releases = read.table(ftp_releases,  fill=T, sep="\t", quote="", header=T)

    speciesDIR = toupper(species)
    fileURL  = paste( "ftp://ftp.ebi.ac.uk/pub/databases/GO/goa/", speciesDIR, "/gene_association.goa_", species, ".gz", sep="" )
    temp = tempfile()
    download.file(fileURL, temp, mode="wb")
    goa <- read.table( gzfile(temp),  sep="\t", comment.char="!")
    comments <- read.table( gzfile(temp),  sep="\t", nrows = 12)
    
    # Convert to data frame
    data <- as.data.frame(goa[,c(3,5,7,13)] )

    godesc = get_version(comments)
    if( !file.exists(godesc) ) { godesc = "godesc.rda" }
    load(godesc)
    
    sapply(1:length(), function(i) populate(i))



    return(data)
}


populate <- function(i){
	line = godesc[which( as.character(godesc[,1]) == data[,2][i] ) ,]
	term = as.character( unlist(line[1]))
	descs = unlist(strsplit( as.character(godesc[which( as.character(godesc[,1]) == data[,2][i] ) ,2]) , " ") )
	return (as.matrix(cbind( data[i,c(1,3)], c(term, descs))))

}


make_network_from_data<- function(data, listA, listB){
  nr = length(listA)
  nc = length(listB)
  
  net = matrix(0, ncol=nc, nrow=nr)
  
  m = match( (data[,1]), listA  )
  p1 = !is.na(m)
  m1 = m[p1]
  
  m = match( (data[p1,2]), listB )
  p2 = !is.na(m)
  m2 = m[p2]
  
  net[cbind(m1,m2)] = 1
  
  colnames(net) = listB
  rownames(net) = listA
  return(net)
}

