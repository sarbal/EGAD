library(testthat)
library(EGAD)

test_check("EGAD")
