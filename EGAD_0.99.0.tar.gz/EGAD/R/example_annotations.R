#' @name example_annotations
#' @title Example of annotations 
#'
#' @description
#' This dataset includes 
#'
#' @docType data
#' 
#'
#' @rdname example_annotations
#'
NULL